<?php

namespace App\Http\Controllers;


use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Agendamentos;

class AgendamentoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getAgendamentos(){

        $agendamentos = [
            ["id_agendamento" => 1, "data" => "2025-04-01", "hora" => "14:00", "nome_Cliente" => "Ricardo Souza", "nome_profissional" => "Salomao Abreu"],
            ["id_agendamento" => 2, "data" => "2025-04-02", "hora" => "10:00", "nome_Cliente" => "Matheus Silva", "nome_profissional" => "Marina Aguiar"],
            ["id_agendamento" => 3, "data" => "2025-04-03", "hora" => "09:30", "nome_Cliente" => "Matias Albuquerque", "nome_profissional" => "Paulo Maltez"],
            ["id_agendamento" => 4, "data" => "2025-04-04", "hora" => "18:00", "nome_Cliente" => "Ana Carla", "nome_profissional" => "Paulo Maltez"],
            ["id_agendamento" => 5, "data" => "2025-04-05", "hora" => "12:00", "nome_Cliente" => "Ricardo Souza", "nome_profissional" => "Marina Aguiar"],
            ["id_agendamento" => 6, "data" => "2025-04-06", "hora" => "16:00", "nome_Cliente" => "Pedro Henrique", "nome_profissional" => "Marina Aguiar"],
            ["id_agendamento" => 7, "data" => "2025-04-07", "hora" => "11:30", "nome_Cliente" => "Carlos Pereira", "nome_profissional" => "Salomao Abreu"],
            ["id_agendamento" => 8, "data" => "2025-04-08", "hora" => "15:00", "nome_Cliente" => "Enzo Linhares", "nome_profissional" => "Paulo Maltez"],
            ["id_agendamento" => 9, "data" => "2025-04-09", "hora" => "09:00", "nome_Cliente" => "Carlos Pereira", "nome_profissional" => "Salomao Abreu"],
            ["id_agendamento" => 10, "data" => "2025-04-10", "hora" => "13:00", "nome_Cliente" => "Matias Albuquerque", "nome_profissional" => "Marina Aguiar"]
            
        ];
        
    return response()->json($agendamentos);
}
}
